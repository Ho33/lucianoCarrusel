create view user as
  select `storemovile2019`.`client`.`NIF`        AS `NIF`,
         `storemovile2019`.`client`.`lastName`   AS `lastName`,
         `storemovile2019`.`client`.`firstName`  AS `firstName`,
         `storemovile2019`.`client`.`postalCode` AS `postalCode`,
         `storemovile2019`.`client`.`adress`     AS `adress`,
         `storemovile2019`.`client`.`birthdate`  AS `birthdate`,
         `storemovile2019`.`client`.`landline`   AS `landline`,
         `storemovile2019`.`client`.`movil`      AS `movil`,
         `storemovile2019`.`client`.`email`      AS `email`,
         `storemovile2019`.`client`.`user`       AS `user`,
         `storemovile2019`.`client`.`password`   AS `password`
  from `storemovile2019`.`client`
  where 1;

